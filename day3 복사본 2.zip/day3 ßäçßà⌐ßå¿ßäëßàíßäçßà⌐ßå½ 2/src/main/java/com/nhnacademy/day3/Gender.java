package com.nhnacademy.day3;

public enum Gender {
    M,F
}
